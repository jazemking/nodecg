module.exports = function (nodecg) {
  // No logic needed here for combining visuals
};