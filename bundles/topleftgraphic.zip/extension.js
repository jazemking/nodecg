module.exports = function (nodecg) {
  nodecg.Replicant('topleft_text', { defaultValue: 'Live Status' });
};