# nodecg-vercel-test

This was a test to see if a basic bundle using `include-nodecg` would work on Vercel.

The test failed as Vercel requires a static site and cannot run `npm run start` which is needed for NodeCG to serve the graphics, dashboard and run the extensions.
